const escapeHtml = (value = '') =>
  String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const formatDate = (dateInput) => {
  const date = dateInput ? new Date(dateInput) : new Date();
  return date.toLocaleDateString('en-NG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

const buildInvoiceHtml = ({ invoiceNumber, customerName, customerEmail, serviceName, amount, currency, paidAt, txRef }) => `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Lasglowtech Invoice ${escapeHtml(invoiceNumber)}</title>
    <style>
      body{font-family:Arial,sans-serif;background:#f8fafc;color:#111827;margin:0;padding:24px}
      .card{max-width:780px;margin:0 auto;background:#fff;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden}
      .hero{background:linear-gradient(135deg,#31185e 0%,#1a0e3f 70%,#ed6e00 100%);color:#fff;padding:24px}
      .hero h1{margin:0;font-size:24px}
      .hero p{margin:8px 0 0;font-size:13px;opacity:.92}
      .body{padding:24px}
      .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
      .meta{font-size:13px;color:#374151}
      table{width:100%;border-collapse:collapse;margin-top:16px}
      th,td{border-bottom:1px solid #e5e7eb;padding:10px;text-align:left;font-size:14px}
      th{color:#6b7280;font-weight:600}
      .total{font-weight:700}
      .footer{padding:14px 24px;color:#6b7280;font-size:12px;border-top:1px solid #e5e7eb}
    </style>
  </head>
  <body>
    <div class="card">
      <div class="hero">
        <h1>Lasglowtech Invoice</h1>
        <p>Professional digital services receipt</p>
      </div>
      <div class="body">
        <div class="grid">
          <div class="meta"><strong>Invoice No:</strong> ${escapeHtml(invoiceNumber)}</div>
          <div class="meta"><strong>Date:</strong> ${escapeHtml(formatDate(paidAt))}</div>
          <div class="meta"><strong>Client:</strong> ${escapeHtml(customerName)}</div>
          <div class="meta"><strong>Email:</strong> ${escapeHtml(customerEmail)}</div>
          <div class="meta"><strong>Payment Ref:</strong> ${escapeHtml(txRef)}</div>
        </div>
        <table>
          <thead>
            <tr><th>Description</th><th>Amount</th></tr>
          </thead>
          <tbody>
            <tr>
              <td>${escapeHtml(serviceName)}</td>
              <td>${escapeHtml(currency)} ${Number(amount || 0).toLocaleString()}</td>
            </tr>
            <tr>
              <td class="total">Total Paid</td>
              <td class="total">${escapeHtml(currency)} ${Number(amount || 0).toLocaleString()}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="footer">
        Thank you for choosing Lasglowtech. For support: lasglowtech@gmail.com
      </div>
    </div>
  </body>
</html>
`;

const buildCertificateHtml = ({
  certificateCode,
  learnerName,
  courseTitle,
  completionDate,
}) => `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Lasglowtech Certificate ${escapeHtml(certificateCode)}</title>
    <style>
      body{font-family:Arial,sans-serif;background:#f3f4f6;margin:0;padding:28px}
      .wrap{max-width:920px;margin:0 auto;background:#fff;border:10px solid #31185e;border-radius:18px;overflow:hidden}
      .head{background:linear-gradient(135deg,#31185e 0%,#1a0e3f 70%,#ed6e00 100%);color:#fff;padding:26px;text-align:center}
      .head h1{margin:0;font-size:34px;letter-spacing:2px}
      .body{padding:38px;text-align:center;color:#111827}
      .body .mini{font-size:14px;color:#6b7280;text-transform:uppercase;letter-spacing:1px}
      .body .name{margin-top:12px;font-size:40px;font-weight:700;color:#1a0e3f}
      .body .course{margin-top:14px;font-size:24px;font-weight:600}
      .body .date{margin-top:14px;font-size:14px;color:#374151}
      .badge{display:inline-block;margin-top:24px;padding:8px 14px;border-radius:999px;background:#ed6e0014;color:#ed6e00;border:1px solid #ed6e0050;font-weight:700;font-size:12px}
      .foot{padding:16px 24px;border-top:1px solid #e5e7eb;color:#6b7280;font-size:12px;text-align:center}
    </style>
  </head>
  <body>
    <div class="wrap">
      <div class="head">
        <h1>LASGLOWTECH</h1>
      </div>
      <div class="body">
        <div class="mini">Certificate of Completion</div>
        <div class="name">${escapeHtml(learnerName)}</div>
        <p>has successfully completed the course</p>
        <div class="course">${escapeHtml(courseTitle)}</div>
        <div class="date">Completion Date: ${escapeHtml(formatDate(completionDate))}</div>
        <div class="badge">Certificate ID: ${escapeHtml(certificateCode)}</div>
      </div>
      <div class="foot">Issued by Lasglowtech Learning Team</div>
    </div>
  </body>
</html>
`;

module.exports = {
  buildInvoiceHtml,
  buildCertificateHtml,
};


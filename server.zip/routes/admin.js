const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const config = require('../config');
const db = require('../db');
const { verifyAdmin } = require('../middlewares/auth');
const { sendBulkEmail } = require('../utils/notifications');

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
});

const jwtSecret = config.secret || process.env.JWT_SECRET || 'lasglowtech-dev-secret';

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const [rows] = await db.query(
      "SELECT id, email, password FROM users WHERE email = ? AND role = 'admin' LIMIT 1",
      [email]
    );
    if (!rows.length) {
      return res.status(401).json({ message: 'Invalid admin credentials.' });
    }

    const admin = rows[0];
    const isValidPassword = await bcrypt.compare(password, admin.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: 'Invalid admin credentials.' });
    }

    const token = jwt.sign(
      { id: admin.id, email: admin.email, role: 'admin' },
      jwtSecret,
      { expiresIn: config.expires_in || '1d' }
    );

    return res.status(200).json({
      message: 'Admin login successful.',
      token,
      admin: {
        id: admin.id,
        email: admin.email,
        role: 'admin',
      },
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

/**
 * One-time setup: create first admin with plain email/password (hashed automatically).
 * Only works when no admin exists. Call once from Postman/browser when deploying.
 * POST /admin/setup { "email": "...", "password": "..." }
 */
router.post('/setup', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const [existing] = await db.query(
      "SELECT id FROM users WHERE role = 'admin' LIMIT 1"
    );
    if (existing.length) {
      return res.status(403).json({
        message: 'Admin already exists. Use login or create-admin script to add more.',
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const username = email.split('@')[0] || 'admin';

    await db.query(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      [username, email, hashedPassword, 'admin']
    );

    return res.status(201).json({
      message: 'Admin created. You can now use POST /admin/login with this email and password.',
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

const normalizeEmails = (input) => {
  if (!input) return [];
  const raw = Array.isArray(input) ? input.join(',') : String(input);
  const matches = raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
  return [...new Set(matches.map((e) => e.trim().toLowerCase()))];
};

const csvEmails = (buffer) => {
  const text = String(buffer || '');
  return normalizeEmails(text);
};

const isTruthy = (value) => String(value).toLowerCase() === 'true' || String(value) === '1';

const resolveRecipients = async ({ emails, includeSubscribers }) => {
  let recipients = normalizeEmails(emails);
  if (includeSubscribers) {
    const [rows] = await db.query(
      `SELECT email FROM email_subscriptions
       UNION
       SELECT email FROM users
       UNION
       SELECT email FROM career_applications`
    );
    recipients = [...new Set([...recipients, ...rows.map((r) => String(r.email || '').toLowerCase())])];
  }
  return recipients;
};

const allowedAttachmentExt = new Set(['.pdf', '.doc', '.docx', '.png', '.jpg', '.jpeg']);
const buildAttachments = (files = []) => {
  return files
    .filter((file) => allowedAttachmentExt.has(path.extname(file.originalname || '').toLowerCase()))
    .map((file) => ({
      filename: file.originalname,
      content: file.buffer,
      contentType: file.mimetype || undefined,
    }));
};

const toHtml = (message = '') => {
  const lines = String(message || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  return lines.length ? `<p style="font-size:14px;line-height:1.7;">${lines.join('<br/>')}</p>` : '<p></p>';
};

const persistCampaign = async ({ subject, bodyHtml, results, createdBy }) => {
  const totalRecipients = results.length;
  const totalSent = results.filter((r) => r.status === 'sent').length;
  const totalFailed = totalRecipients - totalSent;

  const [campaignResult] = await db.query(
    `INSERT INTO bulk_email_campaigns (subject, body_html, total_recipients, total_sent, total_failed, created_by)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [subject, bodyHtml, totalRecipients, totalSent, totalFailed, createdBy || 'admin']
  );

  if (results.length) {
    const values = results.map((row) => [
      campaignResult.insertId,
      row.email,
      row.status === 'sent' ? 'sent' : 'failed',
      row.errorMessage || '',
      row.status === 'sent' ? new Date() : null,
    ]);
    await db.query(
      `INSERT INTO bulk_email_recipients (campaign_id, email, status, error_message, sent_at)
       VALUES ?`,
      [values]
    );
  }

  return { totalRecipients, totalSent, totalFailed, campaignId: campaignResult.insertId };
};

router.post('/bulk-email/send', verifyAdmin, async (req, res) => {
  const { subject, message, emails, includeSubscribers } = req.body;
  if (!subject || !message) {
    return res.status(400).json({ message: 'subject and message are required.' });
  }

  try {
    const recipients = await resolveRecipients({ emails, includeSubscribers });

    if (!recipients.length) {
      return res.status(400).json({ message: 'No valid recipient emails found.' });
    }

    const bodyHtml = toHtml(message);
    const results = await sendBulkEmail({
      recipients,
      subject,
      messageHtml: bodyHtml,
    });
    const stats = await persistCampaign({
      subject,
      bodyHtml,
      results,
      createdBy: req.user?.email || 'admin',
    });

    return res.status(200).json({
      message: 'Bulk email completed.',
      ...stats,
      preview: results.slice(0, 10),
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

router.post('/bulk-email/send-with-files', verifyAdmin, upload.array('attachments', 5), async (req, res) => {
  const { subject, message, emails, includeSubscribers } = req.body;
  if (!subject || !message) {
    return res.status(400).json({ message: 'subject and message are required.' });
  }

  try {
    const recipients = await resolveRecipients({
      emails,
      includeSubscribers: isTruthy(includeSubscribers),
    });
    if (!recipients.length) {
      return res.status(400).json({ message: 'No valid recipient emails found.' });
    }

    const bodyHtml = toHtml(message);
    const attachments = buildAttachments(req.files || []);
    const results = await sendBulkEmail({
      recipients,
      subject,
      messageHtml: bodyHtml,
      attachments,
    });
    const stats = await persistCampaign({
      subject,
      bodyHtml,
      results,
      createdBy: req.user?.email || 'admin',
    });

    return res.status(200).json({
      message: 'Bulk email with attachments completed.',
      ...stats,
      attachmentsIncluded: attachments.length,
      preview: results.slice(0, 10),
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

router.post('/bulk-email/send-csv', verifyAdmin, upload.fields([
  { name: 'file', maxCount: 1 },
  { name: 'attachments', maxCount: 5 },
]), async (req, res) => {
  const { subject, message } = req.body;
  if (!subject || !message) {
    return res.status(400).json({ message: 'subject and message are required.' });
  }
  const csvFile = req.files?.file?.[0];
  if (!csvFile?.buffer) {
    return res.status(400).json({ message: 'CSV file is required.' });
  }

  try {
    const recipients = csvEmails(csvFile.buffer);
    if (!recipients.length) {
      return res.status(400).json({ message: 'No valid emails found in file.' });
    }

    const bodyHtml = toHtml(message);
    const results = await sendBulkEmail({
      recipients,
      subject,
      messageHtml: bodyHtml,
      attachments: buildAttachments(req.files?.attachments || []),
    });
    const stats = await persistCampaign({
      subject,
      bodyHtml,
      results,
      createdBy: req.user?.email || 'admin',
    });

    return res.status(200).json({
      message: 'Bulk email from CSV completed.',
      ...stats,
      preview: results.slice(0, 10),
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

router.get('/bulk-email/campaigns', verifyAdmin, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT id, subject, total_recipients, total_sent, total_failed, created_by, created_at
       FROM bulk_email_campaigns
       ORDER BY id DESC
       LIMIT 100`
    );
    return res.status(200).json(rows);
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

module.exports = router;
